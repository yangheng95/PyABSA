# -*- coding: utf-8 -*-
# project: PyABSA
# file: __init__.py
# time: 2021/7/17
# author: yangheng <yangheng@m.scnu.edu.cn>
# github: https://github.com/yangheng95
# Copyright (C) 2021. All Rights Reserved.

from .bert import BERT

# print('The BERT-baseline model are derived base on replacing the GloVe embedding using BERT. '
#       'And the BERT-baseline model are under testing.')
